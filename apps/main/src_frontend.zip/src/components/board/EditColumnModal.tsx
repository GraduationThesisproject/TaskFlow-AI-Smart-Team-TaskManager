import React, { useState, useEffect } from 'react';
import { Modal, Button, Input, Select, Typography, Card, CardContent, Flex, Stack } from '@taskflow/ui';
import type { Column } from '../../types/board.types';

interface EditColumnModalProps {
  isOpen: boolean;
  onClose: () => void;
  column: Column | null;
  onSave: (columnId: string, data: { name: string; color: string; settings?: any }) => Promise<void>;
}

const colorOptions = [
  { value: '#3B82F6', label: 'Blue', color: '#3B82F6' },
  { value: '#EF4444', label: 'Red', color: '#EF4444' },
  { value: '#10B981', label: 'Green', color: '#10B981' },
  { value: '#F59E0B', label: 'Yellow', color: '#F59E0B' },
  { value: '#8B5CF6', label: 'Purple', color: '#8B5CF6' },
  { value: '#EC4899', label: 'Pink', color: '#EC4899' },
  { value: '#6B7280', label: 'Gray', color: '#6B7280' },
  { value: '#F97316', label: 'Orange', color: '#F97316' },
];

export const EditColumnModal: React.FC<EditColumnModalProps> = ({
  isOpen,
  onClose,
  column,
  onSave
}) => {
  const [name, setName] = useState('');
  const [color, setColor] = useState('#3B82F6');
  const [wipLimit, setWipLimit] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (column) {
      setName(column.name);
      setColor(column.style?.color || '#3B82F6');
      setWipLimit(column.settings?.wipLimit?.limit || 0);
    }
  }, [column]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!column) return;

    setIsLoading(true);
    try {
      await onSave(column._id, {
        name,
        color,
        settings: {
          wipLimit: {
            enabled: wipLimit > 0,
            limit: wipLimit,
            strictMode: false
          }
        }
      });
      onClose();
    } catch (error) {
      console.error('Failed to update column:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="md">
      <Card>
        <CardContent className="p-6">
          <Typography variant="h3" className="mb-6">
            Edit Column
          </Typography>

          <form onSubmit={handleSubmit}>
            <Stack gap={4}>
              <div>
                <Typography variant="body-medium" className="mb-2">
                  Column Name
                </Typography>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter column name"
                  required
                />
              </div>

              <div>
                <Typography variant="body-medium" className="mb-2">
                  Color
                </Typography>
                <Select
                  value={color}
                  onChange={(value) => setColor(value)}
                  options={colorOptions}
                  renderOption={(option) => (
                    <Flex align="center" gap={2}>
                      <div 
                        className="w-4 h-4 rounded-full" 
                        style={{ backgroundColor: option.color }}
                      />
                      <span>{option.label}</span>
                    </Flex>
                  )}
                />
              </div>

              <div>
                <Typography variant="body-medium" className="mb-2">
                  WIP Limit (0 = no limit)
                </Typography>
                <Input
                  type="number"
                  value={wipLimit}
                  onChange={(e) => setWipLimit(parseInt(e.target.value) || 0)}
                  min={0}
                  placeholder="0"
                />
              </div>

              <Flex gap={3} className="mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  disabled={isLoading}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isLoading || !name.trim()}
                  className="flex-1"
                >
                  {isLoading ? 'Saving...' : 'Save Changes'}
                </Button>
              </Flex>
            </Stack>
          </form>
        </CardContent>
      </Card>
    </Modal>
  );
};
