import React from "react";

interface ClockIconProps extends React.SVGProps<SVGSVGElement> {
  size?: number;
}

const ClockIcon: React.FC<ClockIconProps> = ({ size = 20, className, ...props }) => {
  // Maintain original aspect ratio width:height = 20:21
  const width = size * (20 / 21);
  const clipId = React.useId();

  return (
    <svg
      width={width}
      height={size}
      viewBox="0 0 20 21"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      {...props}
    >
      <g clipPath={`url(#${clipId})`}>
        <path d="M10 0.5C12.6522 0.5 15.1957 1.55357 17.0711 3.42893C18.9464 5.3043 20 7.84784 20 10.5C20 13.1522 18.9464 15.6957 17.0711 17.5711C15.1957 19.4464 12.6522 20.5 10 20.5C7.34784 20.5 4.8043 19.4464 2.92893 17.5711C1.05357 15.6957 0 13.1522 0 10.5C0 7.84784 1.05357 5.3043 2.92893 3.42893C4.8043 1.55357 7.34784 0.5 10 0.5ZM9.0625 5.1875V10.5C9.0625 10.8125 9.21875 11.1055 9.48047 11.2812L13.2305 13.7812C13.6602 14.0703 14.2422 13.9531 14.5312 13.5195C14.8203 13.0859 14.7031 12.5078 14.2695 12.2188L10.9375 10V5.1875C10.9375 4.66797 10.5195 4.25 10 4.25C9.48047 4.25 9.0625 4.66797 9.0625 5.1875Z" fill="currentColor"/>
      </g>
      <defs>
        <clipPath id={clipId}>
          <path d="M0 0.5H20V20.5H0V0.5Z" fill="white"/>
        </clipPath>
      </defs>
    </svg>
  );
};

export default ClockIcon;
